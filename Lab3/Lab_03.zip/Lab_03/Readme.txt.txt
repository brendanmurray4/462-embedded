ENSC 462 : Lab 3
Nicholas Polyzogopoulos & Brendan Murray
Mar. 18th. 2022
-----------------------------------------

*File Hierarchy:
Lab_03 / <folder>
	
	- "Xilinx" folder contains our vivado project (called lab3)

	- "spi_controller" folder contains our spi_controller .vhd file, denpendent
		entities .vhd files and a testbench for the spi_controller, as well 
		as modelsim scripts. The /debug folder contains screenshots of the 
		waveforms.

	- "top" folder contains our top level .vhd file and identical copies 
		of the spi_controller and dependents. It also contains modelsim 
		scripts. The /debug folder contains debug screenshots of the 
		waveforms.