ENSC 462 : Lab 1
Nicholas Polyzogopoulos & Brendan Murray
Feb. 4th. 2022
-----------------------------------------

*File Hierarchy:
ENSC 462 / partX /
	
	- Each partX folder contains folder(s) for each entity, top level, and a debug folder:
		~ The entity folder(s) contains the .vhd and testbench .vhd, work directory and .do scripts.
		~ The entity folder that is the top-level contains identical copies of any dependent entities found elsewhere.
		~ The debug folder contains screenshots of waveforms that were generated for each enitity and top level.